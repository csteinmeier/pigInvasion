/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package display;

/**
 *
 * @author christine.steinmeier
 */
public class Hinweis {
    
}
