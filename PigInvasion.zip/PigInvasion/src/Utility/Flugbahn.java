package Utility;

public enum Flugbahn 
{
    LINKS,
    RECHTS,
    HOCH_LINKS,
    HOCH_RECHTS,
    KEINE;
}
